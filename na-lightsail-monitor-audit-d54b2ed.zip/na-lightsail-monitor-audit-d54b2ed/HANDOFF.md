# 交接包 · na-lightsail-monitor 独立审计

**审计对象**：提交 `d54b2ed`（2026-08-22）
**结论入口**：[`AUDIT-REPORT.md`](AUDIT-REPORT.md)，或用浏览器打开 `audit-report.html`（同样内容，排版版）

---

## 这个包里有什么

| 路径 | 是什么 |
| --- | --- |
| `AUDIT-REPORT.md` | **审计报告正文。**10 条发现、21 项核实无误、4 项无法核实，外加架构评估 |
| `audit-report.html` | 同一份报告的网页版，双击即可打开，不需要任何工具 |
| `AUDIT-BRIEF.md` | 本次审计的**委托书**（仓库里的 `AUDIT.md`），说明审计范围和已拍板不重议的事项 |
| `audit-evidence/sim/` | 离散事件模拟器：把真实的 `worker.scheduled` 挂到模拟的指标管道上跑 |
| `audit-evidence/repro/` | 独立于模拟器的最小复现脚本 |
| `audit-evidence/extra-mutations.sh` | 16 个追加变异体（与仓库里那 19 个不重合） |
| `node_modules/aws4fetch/` | 被审代码唯一的运行时依赖，随包附带 |

---

## 开箱即跑

不需要 `npm install`，不需要克隆仓库。只要有 Node 20+：

```bash
cd audit-evidence/sim && node control.mjs
```

**先跑这一个。** 它是模拟器的自检——两个对照组、两个反向用例、两个刻度校验、一项与被审代码的时间戳交叉校验。**如果它不全绿，后面所有数字都不要信。**

自检通过之后，按需要跑：

```bash
cd audit-evidence/repro && node blind-cliff.mjs
```

```bash
cd audit-evidence/repro && node missing-invariants.mjs
```

```bash
cd audit-evidence/sim && node exp-j.mjs
```

---

## 每个脚本证明什么

### `audit-evidence/sim/` — 模拟器

| 脚本 | 对应发现 | 结论 |
| --- | --- | --- |
| `control.mjs` | — | **先跑这个。** 模拟器 7 项自检 |
| `probe-lag.mjs` | — | 注入的落库延迟 L 与被审代码算出的 `meter` 字段交叉校验 |
| `harness.mjs` | — | 管道模型本体；`-nogate` / `-w1800` / `-w3600` 是对照变体 |
| `exp-a.mjs` | F3 | 有闸门 vs 无闸门，逐格对比 |
| `exp-b.mjs` | F3 | 最坏超额扫描；对比调低 `THRESHOLD` 的效果 |
| `exp-c.mjs` | F3 | 把闸门的收益（挡下超额）和代价（多余停机）分开数 |
| `exp-d.mjs` | F3 | 有限的合法大传输会不会被误停 |
| `exp-e.mjs` | F4 | 证伪注释里的两个闭式解候选 |
| `exp-f.mjs` | F4 | 验证新推的闭式解（16/16 对上） |
| `exp-g.mjs` | F1 | 落库延迟扫描：BLIND 告警在哪一段有效 |
| `exp-h.mjs` | F5 | 核对 README 的暴露量表与「164 GiB」 |
| `exp-i.mjs` | F5 F10 | 同上，但扫遍 cron 相位给出区间 |
| `exp-j.mjs` | F2 | 真正的临界落库延迟在哪 |
| `exp-k.mjs` | F3 | 收到文档允许的 5 Gbps 上限内重算最坏超额 |

### `audit-evidence/repro/` — 不依赖模拟器

| 脚本 | 对应发现 | 结论 |
| --- | --- | --- |
| `blind-cliff.mjs` | **F1** | 落库延迟 25→26 分钟时，看门狗从「报警并停机」变成「写 OK 并断言 `now 0 kbps`」 |
| `missing-invariants.mjs` | **F1** | 我独立从需求列的两条不变量被违反（含一条对照，证明探针不是恒失败） |
| `survivors.mjs` | F6 F7 | 刻画两个存活变异：`replaceAll` 未被覆盖；`1e400` → `Infinity` 未被覆盖 |

### `audit-evidence/extra-mutations.sh` — 需要真实仓库

这一个**不能**脱离仓库跑，它要完整的测试套件：

```bash
bash audit-evidence/extra-mutations.sh /path/to/na_lightsail_monitor
```

全程在 `mktemp` 副本里操作，不碰目标仓库。预期结果：11 抓到、3 等价变异存活、2 真实覆盖缺口存活（F6、F7）。

---

## 重要前提

**`audit-evidence/sim/` 和 `repro/` 里各有一份 `src/index.js` 的快照**，内容与 `d54b2ed` 逐字节一致：

```
sha256  6f0b351ec690c268863c0eccc49881b7102976e566c9b36f4249a390e2f1ed88
```

代码改了之后要重跑，**必须先把快照换掉**，否则跑的还是审计时那一版：

```bash
cp /path/to/na_lightsail_monitor/src/index.js audit-evidence/sim/index.js
```

```bash
cp /path/to/na_lightsail_monitor/src/index.js audit-evidence/repro/index.js
```

`sim/` 下的三个变体（`index-nogate.js`、`index-w1800.js`、`index-w3600.js`）是从快照派生的，换了快照也要一并重新生成——生成方式写在 `AUDIT-REPORT.md` 对应实验的说明里，都是单点替换。

---

## 报告怎么读

按这个顺序：

1. **`AUDIT-REPORT.md` 第 1 节（方法）**——先看我怎么验的，以及我自己在建模上踩的两个坑。这决定你要不要信后面的数字。
2. **第 2 节 F1 和 F2**——两条严重发现，都是漏停方向。F1 有最小复现，两分钟能自己跑出来。
3. **第 5 节（架构）**——突发闸门值不值得。这是委托书第 5.5 节点名要回答的开放问题。
4. **第 3、4 节**——覆盖边界。第 3 节说我核实过什么，第 4 节说我没能核实什么以及为什么。

报告里**没有**把「78 个测试通过」当作任何结论的依据，这是委托书明确要求的。

---

## 审计时未改动任何代码

审计全程 `src/`、`test/`、`scripts/`、`README.md`、`wrangler.jsonc`、`package.json` 一个字节都没动，也没有提交或推送。所有发现都只是发现，改不改、怎么改由你决定。
